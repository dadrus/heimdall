// Copyright 2026 Dimitrij Drus <dadrus@gmx.de>
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//      http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// SPDX-License-Identifier: Apache-2.0

package requestlimit

import (
	"context"

	"google.golang.org/grpc"

	limit "github.com/dadrus/heimdall/internal/handler/middleware/requestlimit"
	"github.com/dadrus/heimdall/internal/pipeline"
)

func New(maxInFlight int64) grpc.UnaryServerInterceptor {
	if maxInFlight == 0 {
		return func(ctx context.Context, req any, _ *grpc.UnaryServerInfo, handler grpc.UnaryHandler) (any, error) {
			return handler(ctx, req)
		}
	}

	limiter := limit.New(maxInFlight)

	return func(ctx context.Context, req any, _ *grpc.UnaryServerInfo, handler grpc.UnaryHandler) (any, error) {
		if !limiter.TryAcquire() {
			return nil, pipeline.ErrTooManyRequests
		}

		defer limiter.Release()

		return handler(ctx, req)
	}
}
