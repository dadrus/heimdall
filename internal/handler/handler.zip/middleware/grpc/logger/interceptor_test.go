// Copyright 2023 Dimitrij Drus <dadrus@gmx.de>
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//      http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// SPDX-License-Identifier: Apache-2.0

package logger

import (
	"context"
	"net"
	"net/http"
	"strings"
	"testing"

	envoy_auth "github.com/envoyproxy/go-control-plane/envoy/service/auth/v3"
	envoy_type "github.com/envoyproxy/go-control-plane/envoy/type/v3"
	"github.com/goccy/go-json"
	"github.com/rs/zerolog"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/mock"
	"github.com/stretchr/testify/require"
	"go.opentelemetry.io/contrib/instrumentation/google.golang.org/grpc/otelgrpc"
	"go.opentelemetry.io/otel"
	"go.opentelemetry.io/otel/propagation"
	sdktrace "go.opentelemetry.io/otel/sdk/trace"
	"go.opentelemetry.io/otel/trace"
	rpc_status "google.golang.org/genproto/googleapis/rpc/status"
	"google.golang.org/grpc"
	"google.golang.org/grpc/codes"
	"google.golang.org/grpc/credentials/insecure"
	"google.golang.org/grpc/metadata"
	"google.golang.org/grpc/status"
	"google.golang.org/grpc/test/bufconn"

	"github.com/dadrus/heimdall/internal/accesscontext"
	mocks2 "github.com/dadrus/heimdall/internal/handler/middleware/grpc/mocks"
	"github.com/dadrus/heimdall/internal/x/testsupport"
)

func TestLogInterceptorForKnownService(t *testing.T) {
	otel.SetTracerProvider(sdktrace.NewTracerProvider())
	otel.SetTextMapPropagator(propagation.NewCompositeTextMapPropagator(propagation.TraceContext{}))

	parentCtx := trace.NewSpanContext(trace.SpanContextConfig{
		TraceID:    trace.TraceID{1},
		SpanID:     trace.SpanID{2},
		TraceFlags: trace.FlagsSampled,
	})

	for uc, tc := range map[string]struct {
		outgoingContext func(t *testing.T) context.Context
		requestHeaders  map[string]string
		configureMock   func(t *testing.T, m *mocks2.MockHandler)
		assert          func(t *testing.T, logEvent1, logEvent2, logEvent3 map[string]any)
	}{
		"without tracing, x-* header and errors": {
			outgoingContext: func(t *testing.T) context.Context {
				t.Helper()

				return t.Context()
			},
			configureMock: func(t *testing.T, m *mocks2.MockHandler) {
				t.Helper()

				m.On("Check",
					mock.MatchedBy(
						func(ctx context.Context) bool {
							zerolog.Ctx(ctx).Info().Msg("test called")
							accesscontext.SetSubject(ctx, "foo")

							return true
						},
					),
					mock.Anything,
				).Return(
					&envoy_auth.CheckResponse{Status: &rpc_status.Status{Code: int32(envoy_type.StatusCode_OK)}},
					nil,
				)
			},
			assert: func(t *testing.T, logEvent1, logEvent2, logEvent3 map[string]any) {
				t.Helper()

				require.Len(t, logEvent1, 7)
				assert.Equal(t, "info", logEvent1["level"])
				assert.Contains(t, logEvent1, "_tx_start")
				assert.Contains(t, logEvent1, "_client_ip")
				assert.Equal(t, "/envoy.service.auth.v3.Authorization/Check", logEvent1["_grpc_method"])
				assert.Contains(t, logEvent1, "_trace_id")
				assert.Contains(t, logEvent1, "_span_id")
				assert.NotContains(t, logEvent1, "_parent_id")
				assert.NotEqual(t, parentCtx.TraceID().String(), logEvent1["_trace_id"])
				assert.Equal(t, "TX started", logEvent1["message"])

				require.Len(t, logEvent2, 4)
				assert.Equal(t, "info", logEvent2["level"])
				assert.Contains(t, logEvent2, "_trace_id")
				assert.Contains(t, logEvent2, "_span_id")
				assert.Equal(t, logEvent1["_trace_id"], logEvent2["_trace_id"])
				assert.Equal(t, logEvent1["_span_id"], logEvent2["_span_id"])
				assert.Equal(t, "test called", logEvent2["message"])

				require.Len(t, logEvent3, 11)
				assert.Equal(t, "info", logEvent3["level"])
				assert.Contains(t, logEvent3, "_tx_start")
				assert.Contains(t, logEvent3, "_tx_duration_ms")
				assert.Contains(t, logEvent3, "_client_ip")
				assert.Equal(t, logEvent1["_grpc_method"], logEvent3["_grpc_method"])
				assert.Contains(t, logEvent3, "_trace_id")
				assert.Contains(t, logEvent3, "_span_id")
				assert.NotContains(t, logEvent3, "_prent_id")
				assert.Equal(t, logEvent1["_trace_id"], logEvent3["_trace_id"])
				assert.Equal(t, logEvent1["_span_id"], logEvent3["_span_id"])
				assert.Equal(t, true, logEvent3["_access_granted"]) //nolint:testifylint
				assert.Equal(t, "foo", logEvent3["_subject"])
				assert.InDelta(t, float64(codes.OK), logEvent3["_grpc_status_code"], 0.001)
				assert.Equal(t, "TX finished", logEvent3["message"])
			},
		},
		"with tracing, x-* header and error": {
			outgoingContext: func(t *testing.T) context.Context {
				t.Helper()

				md := map[string]string{
					"x-forwarded-for": "203.0.113.1",
					"forwarded":       "for=203.0.113.1",
				}

				otel.GetTextMapPropagator().Inject(
					trace.ContextWithRemoteSpanContext(t.Context(), parentCtx),
					propagation.MapCarrier(md),
				)

				return metadata.NewOutgoingContext(t.Context(), metadata.New(md))
			},
			requestHeaders: map[string]string{
				"x-forwarded-for": "127.0.0.1",
				"forwarded":       "for=127.0.0.1",
			},
			configureMock: func(t *testing.T, m *mocks2.MockHandler) {
				t.Helper()

				m.On(
					"Check",
					mock.MatchedBy(
						func(ctx context.Context) bool {
							zerolog.Ctx(ctx).Info().Msg("test called")

							return true
						},
					),
					mock.Anything,
				).Return(nil, assert.AnError)
			},
			assert: func(t *testing.T, logEvent1, logEvent2, logEvent3 map[string]any) {
				t.Helper()

				require.Len(t, logEvent1, 10)
				assert.Equal(t, "info", logEvent1["level"])
				assert.Contains(t, logEvent1, "_tx_start")
				assert.Contains(t, logEvent1, "_client_ip")
				assert.Equal(t, "/envoy.service.auth.v3.Authorization/Check", logEvent1["_grpc_method"])
				assert.Contains(t, logEvent1, "_span_id")
				assert.Equal(t, parentCtx.TraceID().String(), logEvent1["_trace_id"])
				assert.Equal(t, parentCtx.SpanID().String(), logEvent1["_parent_id"])
				assert.Equal(t, "for=127.0.0.1", logEvent1["_forwarded"])
				assert.Equal(t, "127.0.0.1", logEvent1["_x_forwarded_for"])
				assert.Equal(t, "TX started", logEvent1["message"])

				require.Len(t, logEvent2, 5)
				assert.Equal(t, "info", logEvent2["level"])
				assert.Contains(t, logEvent2, "_trace_id")
				assert.Contains(t, logEvent2, "_span_id")
				assert.Contains(t, logEvent2, "_parent_id")
				assert.Equal(t, logEvent1["_trace_id"], logEvent2["_trace_id"])
				assert.Equal(t, logEvent1["_span_id"], logEvent2["_span_id"])
				assert.Equal(t, logEvent1["_parent_id"], logEvent2["_parent_id"])
				assert.Equal(t, "test called", logEvent2["message"])

				require.Len(t, logEvent3, 14)
				assert.Equal(t, "info", logEvent3["level"])
				assert.Contains(t, logEvent3, "_tx_start")
				assert.Contains(t, logEvent3, "_tx_duration_ms")
				assert.Contains(t, logEvent3, "_client_ip")
				assert.Equal(t, logEvent1["_grpc_method"], logEvent3["_grpc_method"])
				assert.Equal(t, logEvent1["_trace_id"], logEvent3["_trace_id"])
				assert.Equal(t, logEvent1["_parent_id"], logEvent3["_parent_id"])
				assert.Equal(t, logEvent1["_span_id"], logEvent3["_span_id"])
				assert.Equal(t, false, logEvent3["_access_granted"]) //nolint:testifylint
				assert.Equal(t, assert.AnError.Error(), logEvent3["error"])
				assert.Equal(t, "for=127.0.0.1", logEvent3["_forwarded"])
				assert.Equal(t, "127.0.0.1", logEvent3["_x_forwarded_for"])
				assert.InDelta(t, float64(codes.Unknown), logEvent3["_grpc_status_code"], 0.001)
				assert.Equal(t, "TX finished", logEvent3["message"])
			},
		},
		"without tracing and x-* header, but with subject and error set on context": {
			outgoingContext: func(t *testing.T) context.Context {
				t.Helper()

				return t.Context()
			},
			configureMock: func(t *testing.T, m *mocks2.MockHandler) {
				t.Helper()

				m.On("Check",
					mock.MatchedBy(
						func(ctx context.Context) bool {
							zerolog.Ctx(ctx).Info().Msg("test called")
							accesscontext.SetSubject(ctx, "bar")
							accesscontext.SetError(ctx, assert.AnError)

							return true
						},
					),
					mock.Anything,
				).Return(
					&envoy_auth.CheckResponse{
						Status: &rpc_status.Status{
							Code: int32(envoy_type.StatusCode_Forbidden),
						},
					},
					nil,
				)
			},
			assert: func(t *testing.T, logEvent1, logEvent2, logEvent3 map[string]any) {
				t.Helper()

				require.Len(t, logEvent1, 7)
				assert.Equal(t, "info", logEvent1["level"])
				assert.Contains(t, logEvent1, "_tx_start")
				assert.Contains(t, logEvent1, "_client_ip")
				assert.Equal(t, "/envoy.service.auth.v3.Authorization/Check", logEvent1["_grpc_method"])
				assert.Contains(t, logEvent1, "_trace_id")
				assert.Contains(t, logEvent1, "_span_id")
				assert.NotEqual(t, parentCtx.TraceID().String(), logEvent1["_trace_id"])
				assert.NotEqual(t, parentCtx.SpanID().String(), logEvent1["_parent_id"])
				assert.Equal(t, "TX started", logEvent1["message"])

				require.Len(t, logEvent2, 4)
				assert.Equal(t, "info", logEvent2["level"])
				assert.Contains(t, logEvent2, "_trace_id")
				assert.Contains(t, logEvent2, "_span_id")
				assert.NotContains(t, logEvent2, "_parent_id")
				assert.Equal(t, logEvent1["_trace_id"], logEvent2["_trace_id"])
				assert.Equal(t, logEvent1["_span_id"], logEvent2["_span_id"])
				assert.Equal(t, "test called", logEvent2["message"])

				require.Len(t, logEvent3, 12)
				assert.Equal(t, "info", logEvent3["level"])
				assert.Contains(t, logEvent3, "_tx_start")
				assert.Contains(t, logEvent3, "_tx_duration_ms")
				assert.Contains(t, logEvent3, "_client_ip")
				assert.Equal(t, logEvent1["_grpc_method"], logEvent3["_grpc_method"])
				assert.Contains(t, logEvent3, "_trace_id")
				assert.Contains(t, logEvent3, "_span_id")
				assert.Equal(t, logEvent1["_trace_id"], logEvent3["_trace_id"])
				assert.Equal(t, logEvent1["_parent_id"], logEvent3["_parent_id"])
				assert.Equal(t, false, logEvent3["_access_granted"]) //nolint:testifylint
				assert.Equal(t, "bar", logEvent3["_subject"])
				assert.Equal(t, assert.AnError.Error(), logEvent3["error"])
				assert.InDelta(t, float64(codes.OK), logEvent3["_grpc_status_code"], 0.001)
				assert.Equal(t, "TX finished", logEvent3["message"])
			},
		},
	} {
		t.Run(uc, func(t *testing.T) {
			var (
				logLine1 map[string]any
				logLine2 map[string]any
				logLine3 map[string]any
			)

			lis := bufconn.Listen(1024 * 1024)
			tb := &testsupport.TestingLog{TB: t}
			logger := zerolog.New(zerolog.TestWriter{T: tb})
			handler := &mocks2.MockHandler{}

			conn, err := grpc.NewClient(
				"passthrough://bufnet",
				grpc.WithContextDialer(
					func(context.Context, string) (net.Conn, error) {
						return lis.Dial()
					},
				),
				grpc.WithTransportCredentials(insecure.NewCredentials()),
			)
			require.NoError(t, err)

			defer conn.Close()

			tc.configureMock(t, handler)

			srv := grpc.NewServer(
				grpc.StatsHandler(otelgrpc.NewServerHandler()),
				grpc.ChainUnaryInterceptor(New(logger).UnaryServerInterceptor()),
			)
			envoy_auth.RegisterAuthorizationServer(srv, handler)

			go func() {
				srv.Serve(lis)
			}()

			client := envoy_auth.NewAuthorizationClient(conn)

			// WHEN
			client.Check(tc.outgoingContext(t), &envoy_auth.CheckRequest{
				Attributes: &envoy_auth.AttributeContext{
					Request: &envoy_auth.AttributeContext_Request{
						Http: &envoy_auth.AttributeContext_HttpRequest{
							Body:    "foo",
							Method:  http.MethodPost,
							Path:    "/foobar",
							Headers: tc.requestHeaders,
						},
					},
				},
			})

			// THEN
			srv.Stop()

			events := strings.Split(tb.CollectedLog(), "}")
			require.Len(t, events, 4)

			require.NoError(t, json.Unmarshal([]byte(events[0]+"}"), &logLine1))
			require.NoError(t, json.Unmarshal([]byte(events[1]+"}"), &logLine2))
			require.NoError(t, json.Unmarshal([]byte(events[2]+"}"), &logLine3))

			tc.assert(t, logLine1, logLine2, logLine3)
			handler.AssertExpectations(t)
		})
	}
}

func TestLogInterceptorWithAccessLogDisabled(t *testing.T) {
	otel.SetTracerProvider(sdktrace.NewTracerProvider())
	otel.SetTextMapPropagator(propagation.NewCompositeTextMapPropagator(propagation.TraceContext{}))

	lis := bufconn.Listen(1024 * 1024)
	tb := &testsupport.TestingLog{TB: t}
	logger := zerolog.New(zerolog.TestWriter{T: tb})
	handler := &mocks2.MockHandler{}

	conn, err := grpc.NewClient(
		"passthrough://bufnet",
		grpc.WithContextDialer(
			func(context.Context, string) (net.Conn, error) {
				return lis.Dial()
			},
		),
		grpc.WithTransportCredentials(insecure.NewCredentials()),
	)
	require.NoError(t, err)

	defer conn.Close()

	handler.On(
		"Check",
		mock.MatchedBy(
			func(ctx context.Context) bool {
				zerolog.Ctx(ctx).Info().Msg("test called")

				return true
			},
		),
		mock.Anything,
	).Return(
		&envoy_auth.CheckResponse{
			Status: &rpc_status.Status{
				Code: int32(envoy_type.StatusCode_OK),
			},
		},
		nil,
	)

	srv := grpc.NewServer(
		grpc.StatsHandler(otelgrpc.NewServerHandler()),
		grpc.ChainUnaryInterceptor(New(logger, WithAccessLogEnabled(false)).UnaryServerInterceptor()),
	)
	envoy_auth.RegisterAuthorizationServer(srv, handler)

	go func() {
		srv.Serve(lis)
	}()

	client := envoy_auth.NewAuthorizationClient(conn)

	// WHEN
	_, err = client.Check(t.Context(), &envoy_auth.CheckRequest{
		Attributes: &envoy_auth.AttributeContext{
			Request: &envoy_auth.AttributeContext_Request{
				Http: &envoy_auth.AttributeContext_HttpRequest{
					Body:   "foo",
					Method: http.MethodPost,
					Path:   "/foobar",
				},
			},
		},
	})

	// THEN
	require.NoError(t, err)
	srv.Stop()

	events := strings.Split(strings.TrimRight(tb.CollectedLog(), "\n"), "}")
	// only "test called" log event should be present, no TX started / finished
	require.Len(t, events, 2)

	var logLine map[string]any
	require.NoError(t, json.Unmarshal([]byte(events[0]+"}"), &logLine))

	assert.Equal(t, "test called", logLine["message"])
	assert.Equal(t, "info", logLine["level"])

	handler.AssertExpectations(t)
}

func TestLogInterceptorStreamWithAccessLogDisabled(t *testing.T) {
	otel.SetTracerProvider(sdktrace.NewTracerProvider())
	otel.SetTextMapPropagator(propagation.NewCompositeTextMapPropagator(propagation.TraceContext{}))

	lis := bufconn.Listen(1024 * 1024)
	tb := &testsupport.TestingLog{TB: t}
	logger := zerolog.New(zerolog.TestWriter{T: tb})
	handler := &mocks2.MockHandler{}

	conn, err := grpc.NewClient("passthrough://bufnet",
		grpc.WithContextDialer(func(context.Context, string) (net.Conn, error) { return lis.Dial() }),
		grpc.WithTransportCredentials(insecure.NewCredentials()))
	require.NoError(t, err)

	defer conn.Close()

	srv := grpc.NewServer(
		grpc.UnknownServiceHandler(func(_ any, _ grpc.ServerStream) error {
			return status.Error(codes.Unknown, "unknown service or method")
		}),
		grpc.StatsHandler(otelgrpc.NewServerHandler()),
		grpc.ChainStreamInterceptor(New(logger, WithAccessLogEnabled(false)).StreamServerInterceptor()),
	)
	envoy_auth.RegisterAuthorizationServer(srv, handler)

	go func() {
		srv.Serve(lis)
	}()

	client := mocks2.NewTestClient(conn)

	// WHEN
	_, err = client.Test(t.Context(), &mocks2.TestRequest{})

	// THEN
	require.Error(t, err)
	srv.Stop()
	handler.AssertExpectations(t)

	// no TX events must be emitted
	assert.Empty(t, strings.TrimSpace(tb.CollectedLog()))
}

func TestLogInterceptorForUnknownService(t *testing.T) {
	otel.SetTracerProvider(sdktrace.NewTracerProvider())
	otel.SetTextMapPropagator(propagation.NewCompositeTextMapPropagator(propagation.TraceContext{}))

	var (
		logEvent1 map[string]any
		logEvent2 map[string]any
	)

	lis := bufconn.Listen(1024 * 1024)
	tb := &testsupport.TestingLog{TB: t}
	logger := zerolog.New(zerolog.TestWriter{T: tb})
	handler := &mocks2.MockHandler{}
	bufDialer := func(context.Context, string) (net.Conn, error) {
		return lis.Dial()
	}

	conn, err := grpc.NewClient(
		"passthrough://bufnet",
		grpc.WithContextDialer(bufDialer),
		grpc.WithTransportCredentials(insecure.NewCredentials()),
	)
	require.NoError(t, err)

	defer conn.Close()

	srv := grpc.NewServer(
		grpc.UnknownServiceHandler(
			func(_ any, _ grpc.ServerStream) error {
				return status.Error(codes.Unknown, "unknown service or method")
			},
		),
		grpc.StatsHandler(otelgrpc.NewServerHandler()),
		grpc.ChainStreamInterceptor(New(logger).StreamServerInterceptor()),
	)
	envoy_auth.RegisterAuthorizationServer(srv, handler)

	go func() {
		srv.Serve(lis)
	}()

	client := mocks2.NewTestClient(conn)

	// WHEN
	_, err = client.Test(t.Context(), &mocks2.TestRequest{})

	// THEN
	require.Error(t, err)
	srv.Stop()
	handler.AssertExpectations(t)

	events := strings.Split(tb.CollectedLog(), "}")
	require.Len(t, events, 3)

	require.NoError(t, json.Unmarshal([]byte(events[0]+"}"), &logEvent1))
	require.NoError(t, json.Unmarshal([]byte(events[1]+"}"), &logEvent2))

	require.Len(t, logEvent1, 7)
	assert.Equal(t, "info", logEvent1["level"])
	assert.Contains(t, logEvent1, "_tx_start")
	assert.Contains(t, logEvent1, "_client_ip")
	assert.Equal(t, "/test.Test/Test", logEvent1["_grpc_method"])
	assert.Contains(t, logEvent1, "_trace_id")
	assert.Contains(t, logEvent1, "_trace_id")
	assert.Equal(t, "TX started", logEvent1["message"])

	require.Len(t, logEvent2, 11)
	assert.Equal(t, "info", logEvent2["level"])
	assert.Contains(t, logEvent2, "_tx_start")
	assert.Contains(t, logEvent2, "_tx_duration_ms")
	assert.Contains(t, logEvent2, "_client_ip")
	assert.Equal(t, logEvent1["_grpc_method"], logEvent2["_grpc_method"])
	assert.Contains(t, logEvent2, "_trace_id")
	assert.Contains(t, logEvent2, "_trace_id")
	assert.Equal(t, logEvent1["_trace_id"], logEvent2["_trace_id"])
	assert.Equal(t, logEvent1["_parent_id"], logEvent2["_parent_id"])
	assert.Equal(t, false, logEvent2["_access_granted"]) //nolint:testifylint
	assert.Contains(t, logEvent2["error"], "unknown service or method")
	assert.InDelta(t, float64(codes.Unknown), logEvent2["_grpc_status_code"], 0.001)
	assert.Equal(t, "TX finished", logEvent2["message"])
}
