// Copyright 2023 Dimitrij Drus <dadrus@gmx.de>
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//      http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// SPDX-License-Identifier: Apache-2.0

package errorhandler

import (
	"errors"
	"net/http"

	"github.com/rs/zerolog"

	"github.com/dadrus/heimdall/internal/accesscontext"
	"github.com/dadrus/heimdall/internal/pipeline"
	"github.com/dadrus/heimdall/internal/x/stringx"
)

type ErrorHandler interface {
	HandleError(rw http.ResponseWriter, req *http.Request, err error)
}

func New(opts ...Option) ErrorHandler {
	options := defaultOptions()

	for _, opt := range opts {
		opt(options)
	}

	return &errorHandler{opts: options}
}

type errorHandler struct {
	*opts
}

func writeCustomResponse(
	rw http.ResponseWriter,
	responseError *pipeline.ResponseError,
	logger *zerolog.Logger,
) {
	for name, values := range responseError.Headers {
		for _, value := range values {
			rw.Header().Add(name, value)
		}
	}

	rw.WriteHeader(responseError.Code)

	if len(responseError.Body) == 0 {
		return
	}

	if _, err := rw.Write(stringx.ToBytes(responseError.Body)); err != nil {
		logger.Error().Err(err).Msg("Internal error occurred")
	}
}

func hasCustomResponse(responseError *pipeline.ResponseError) bool {
	return responseError.Code != 0 ||
		len(responseError.Headers) != 0 ||
		len(responseError.Body) != 0
}

//nolint:cyclop
func (h *errorHandler) HandleError(rw http.ResponseWriter, req *http.Request, err error) {
	ctx := req.Context()
	logger := zerolog.Ctx(ctx)

	if responseError, ok := errors.AsType[*pipeline.ResponseError](err); ok {
		if hasCustomResponse(responseError) {
			writeCustomResponse(rw, responseError, logger)

			accesscontext.SetError(ctx, responseError.Cause)

			return
		}

		err = responseError.Cause
	}

	if challengeError, ok := errors.AsType[*pipeline.AuthenticationChallengeError](err); ok {
		rw.Header().Set("WWW-Authenticate", challengeError.Challenge())
	}

	switch {
	case errors.Is(err, pipeline.ErrAuthentication):
		h.onAuthenticationError(rw, req, err)
	case errors.Is(err, pipeline.ErrAuthorization):
		h.onAuthorizationError(rw, req, err)
	case errors.Is(err, pipeline.ErrRequestBodyTooLarge):
		h.onRequestBodyTooLarge(rw, req, err)
	case errors.Is(err, pipeline.ErrCommunicationTimeout) || errors.Is(err, pipeline.ErrCommunication):
		h.onCommunicationError(rw, req, err)
	case errors.Is(err, pipeline.ErrArgument):
		h.onPreconditionError(rw, req, err)
	case errors.Is(err, pipeline.ErrNoRuleFound):
		h.onNoRuleError(rw, req, err)
	case errors.Is(err, &pipeline.RedirectError{}):
		redirectError, _ := errors.AsType[*pipeline.RedirectError](err)

		rw.Header().Set("Location", redirectError.RedirectTo)
		rw.WriteHeader(redirectError.Code)
	case errors.Is(err, pipeline.ErrTooManyRequests):
		h.onTooManyRequestsError(rw, req, err)
	default:
		logger.Error().Err(err).Msg("Internal error occurred")

		h.onInternalError(rw, req, err)
	}

	accesscontext.SetError(ctx, err)
}
