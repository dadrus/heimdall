// Copyright 2023 Dimitrij Drus <dadrus@gmx.de>
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//      http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// SPDX-License-Identifier: Apache-2.0

package grpcv3

import (
	"context"

	envoy_auth "github.com/envoyproxy/go-control-plane/envoy/service/auth/v3"
	envoy_type "github.com/envoyproxy/go-control-plane/envoy/type/v3"
	"google.golang.org/genproto/googleapis/rpc/status"
	"google.golang.org/grpc/codes"

	"github.com/dadrus/heimdall/internal/x/httpx"
)

type requestCoordinator interface {
	Handle(ri requestInput, ct commitTarget) (*envoy_auth.CheckResponse, error)
}

type Handler struct {
	c requestCoordinator
}

func (h *Handler) Check(ctx context.Context, req *envoy_auth.CheckRequest) (*envoy_auth.CheckResponse, error) {
	if !httpx.IsValidAuthority(req.GetAttributes().GetRequest().GetHttp().GetHost()) {
		return &envoy_auth.CheckResponse{
			Status: &status.Status{Code: int32(codes.OK)},
			HttpResponse: &envoy_auth.CheckResponse_DeniedResponse{
				DeniedResponse: &envoy_auth.DeniedHttpResponse{
					Status: &envoy_type.HttpStatus{
						Code: envoy_type.StatusCode_BadRequest,
					},
				},
			},
		}, nil
	}

	return h.c.Handle(requestInput{ctx: ctx, req: req}, commitTarget{})
}
