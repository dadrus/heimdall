// Copyright 2023 Dimitrij Drus <dadrus@gmx.de>
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//      http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// SPDX-License-Identifier: Apache-2.0

package grpcv3

import (
	"context"
	"io"
	"net"
	"net/http"
	"testing"

	envoy_auth "github.com/envoyproxy/go-control-plane/envoy/service/auth/v3"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
	"google.golang.org/grpc/peer"
)

func TestNewRequestContext(t *testing.T) {
	t.Parallel()

	// GIVEN
	httpReq := &envoy_auth.AttributeContext_HttpRequest{
		Method: http.MethodPatch,
		Scheme: "https",
		Host:   "FoO.Bar:8080",
		Path:   "/test/baz?bar=moo#foobar",
		Headers: map[string]string{
			"x-foo-bar":       "barfoo",
			"x-forwarded-for": "127.0.0.1",
		},
	}
	checkReq := &envoy_auth.CheckRequest{
		Attributes: &envoy_auth.AttributeContext{
			Request: &envoy_auth.AttributeContext_Request{
				Http: httpReq,
			},
		},
	}

	grpcCtx := peer.NewContext(t.Context(), &peer.Peer{
		Addr: &net.TCPAddr{
			IP:   net.ParseIP("192.168.1.1"),
			Port: 12345,
		},
	})

	cf := newContextFactory()
	ctx := cf.Create(requestInput{
		ctx: grpcCtx,
		req: checkReq,
	})

	defer cf.Destroy(ctx)

	// THEN
	assert.Equal(t, httpReq.GetMethod(), ctx.Request().Method)
	assert.Equal(t, httpReq.GetScheme(), ctx.Request().URL.Scheme)
	assert.Equal(t, "foo.bar:8080", ctx.Request().URL.Host)
	assert.Equal(t, "/test/baz", ctx.Request().URL.Path)
	assert.Empty(t, ctx.Request().URL.Fragment)
	assert.Equal(t, "bar=moo#foobar", ctx.Request().URL.RawQuery)
	assert.Equal(t, "moo#foobar", ctx.Request().URL.URL.Query().Get("bar"))
	assert.Equal(t, "foo.bar:8080", ctx.Request().Header("Host"))
	assert.Equal(t, "barfoo", ctx.Request().Header("X-Foo-Bar"))
	assert.Equal(t, grpcCtx, ctx.Context())
	assert.Equal(t, []string{"127.0.0.1", "192.168.1.1"}, ctx.Request().ClientIPAddresses)
}

func TestRequestContextURL(t *testing.T) {
	t.Parallel()

	cf := newContextFactory()

	for uc, tc := range map[string]struct {
		requestPath string
		path        string
		rawPath     string
		rawQuery    string
		forceQuery  bool
	}{
		"regular path": {
			requestPath: "/test/baz?bar=moo#foobar",
			path:        "/test/baz",
			rawPath:     "/test/baz",
			rawQuery:    "bar=moo#foobar",
		},
		"empty query": {
			requestPath: "/test?",
			path:        "/test",
			rawPath:     "/test",
			forceQuery:  true,
		},
		"escaped characters": {
			requestPath: "/test%2Ffoo/bar/%5Bval%5D?foo=bar",
			path:        "/test/foo/bar/[val]",
			rawPath:     "/test%2Ffoo/bar/%5Bval%5D",
			rawQuery:    "foo=bar",
		},
		"dot segments": {
			requestPath: "/bar/../test/foo/%5Bval%5D?bar=foo",
			path:        "/test/foo/[val]",
			rawPath:     "/test/foo/%5Bval%5D",
			rawQuery:    "bar=foo",
		},
		"encoded dot segments": {
			requestPath: "/bar/%2e.%2ftest/foo/%5Bval%5D?bar=foo",
			path:        "/bar/../test/foo/[val]",
			rawPath:     "/bar/%2e.%2ftest/foo/%5Bval%5D",
			rawQuery:    "bar=foo",
		},
		"encoded dot segments are retained if another byte requires escaping": {
			requestPath: "/admin/%2e%2e%2fpublic/x|",
			path:        "/admin/../public/x|",
			rawPath:     "/admin/%2e%2e%2fpublic/x%7C",
		},
		"encoded slash is retained if another byte requires escaping": {
			requestPath: "/files/a%2Fb|",
			path:        "/files/a/b|",
			rawPath:     "/files/a%2Fb%7C",
		},
		"trailing slash": {
			requestPath: "/bar/baz/",
			path:        "/bar/baz/",
			rawPath:     "/bar/baz/",
		},
		"root path": {
			requestPath: "/",
			path:        "/",
			rawPath:     "/",
		},
		"adjacent slashes": {
			requestPath: "/api//admin",
			path:        "/api/admin",
			rawPath:     "/api/admin",
		},
	} {
		t.Run(uc, func(t *testing.T) {
			t.Parallel()

			ctx := cf.Create(
				requestInput{
					ctx: t.Context(),
					req: &envoy_auth.CheckRequest{
						Attributes: &envoy_auth.AttributeContext{
							Request: &envoy_auth.AttributeContext_Request{
								Http: &envoy_auth.AttributeContext_HttpRequest{
									Path: tc.requestPath,
								},
							},
						},
					},
				},
			)

			defer cf.Destroy(ctx)

			assert.Equal(t, tc.path, ctx.Request().URL.Path)
			assert.Equal(t, tc.rawPath, ctx.Request().URL.RawPath)
			assert.Equal(t, tc.rawPath, ctx.Request().URL.EscapedPath())
			assert.Equal(t, tc.rawQuery, ctx.Request().URL.RawQuery)
			assert.Equal(t, tc.forceQuery, ctx.Request().URL.ForceQuery)
		})
	}
}

func TestRequestContextUpstreamRequest(t *testing.T) {
	t.Parallel()

	for uc, tc := range map[string]struct {
		prepared bool
	}{
		"upstream request is not available before preparation": {},
		"upstream request is available after preparation": {
			prepared: true,
		},
	} {
		t.Run(uc, func(t *testing.T) {
			// GIVEN
			ctx := newRequestContext()
			ctx.Init(
				t.Context(),
				&envoy_auth.CheckRequest{
					Attributes: &envoy_auth.AttributeContext{
						Request: &envoy_auth.AttributeContext_Request{
							Http: &envoy_auth.AttributeContext_HttpRequest{
								Method: http.MethodGet,
								Scheme: "https",
								Host:   "foo.bar",
								Path:   "/test",
							},
						},
					},
				},
			)

			if tc.prepared {
				ctx.PrepareUpstreamView(nil)
			}

			// WHEN
			upstreamRequest := ctx.UpstreamRequest()

			// THEN
			if tc.prepared {
				require.NotNil(t, upstreamRequest)
				assert.Same(t, ctx, upstreamRequest)
			} else {
				assert.Nil(t, upstreamRequest)
			}
		})
	}
}

func TestRequestContextInternalMetadataIsNotExposed(t *testing.T) {
	t.Parallel()

	// GIVEN
	ctx := newRequestContext()
	ctx.Init(
		t.Context(),
		&envoy_auth.CheckRequest{
			Attributes: &envoy_auth.AttributeContext{
				Request: &envoy_auth.AttributeContext_Request{
					Http: &envoy_auth.AttributeContext_HttpRequest{
						Host: "foo.bar",
						Headers: map[string]string{
							"x-foo":                     "bar",
							"x-envoy-auth-partial-body": "false",
						},
					},
				},
			},
		},
	)

	// WHEN
	headers := ctx.Headers()

	// THEN
	assert.Equal(t, "bar", headers.Get("X-Foo"))
	assert.Equal(t, "foo.bar", headers.Get("Host"))
	assert.Empty(t, headers.Get("X-Envoy-Auth-Partial-Body"))
	assert.Empty(t, ctx.Request().Header("X-Envoy-Auth-Partial-Body"))
}

func TestRequestContextRawBody(t *testing.T) {
	t.Parallel()

	for uc, tc := range map[string]struct {
		body              string
		rawBody           []byte
		partialBodyHeader string
		expected          string
		expectError       bool
	}{
		"no body": {
			partialBodyHeader: "false",
		},
		"raw body is available": {
			rawBody:           []byte("raw"),
			body:              "body",
			partialBodyHeader: "false",
			expected:          "raw",
		},
		"body is used if raw body is not available": {
			body:              "content=heimdall",
			partialBodyHeader: "false",
			expected:          "content=heimdall",
		},
		"partial body is rejected": {
			rawBody:           []byte("partial"),
			partialBodyHeader: "true",
			expectError:       true,
		},
		"missing partial body indicator is rejected": {
			rawBody:     []byte("content=heimdall"),
			expectError: true,
		},
	} {
		t.Run(uc, func(t *testing.T) {
			// GIVEN
			headers := map[string]string{}
			if len(tc.partialBodyHeader) != 0 {
				headers["x-envoy-auth-partial-body"] = tc.partialBodyHeader
			}

			ctx := newRequestContext()
			ctx.Init(
				t.Context(),
				&envoy_auth.CheckRequest{
					Attributes: &envoy_auth.AttributeContext{
						Request: &envoy_auth.AttributeContext_Request{
							Http: &envoy_auth.AttributeContext_HttpRequest{
								Path:    "/test",
								Body:    tc.body,
								RawBody: tc.rawBody,
								Headers: headers,
							},
						},
					},
				},
			)

			// WHEN
			body, err := ctx.RawBody()

			// THEN
			if tc.expectError {
				require.Error(t, err)
				assert.Nil(t, body)

				return
			}

			require.NoError(t, err)
			require.NotNil(t, body)

			data, err := io.ReadAll(body)
			require.NoError(t, err)
			require.NoError(t, body.Close())

			assert.Equal(t, tc.expected, string(data))
		})
	}
}

func TestRequestContextReset(t *testing.T) {
	t.Parallel()

	// GIVEN
	ctx := newRequestContext()
	ctx.Init(
		t.Context(),
		&envoy_auth.CheckRequest{
			Attributes: &envoy_auth.AttributeContext{
				Request: &envoy_auth.AttributeContext_Request{
					Http: &envoy_auth.AttributeContext_HttpRequest{
						Path:    "/test",
						RawBody: []byte("content=heimdall"),
						Headers: map[string]string{
							"x-envoy-auth-partial-body": "false",
						},
					},
				},
			},
		},
	)
	ctx.PrepareUpstreamView(nil)

	require.NotNil(t, ctx.bodySource.body)
	require.NotNil(t, ctx.UpstreamRequest())

	// WHEN
	ctx.Reset()

	// THEN
	require.Nil(t, ctx.bodySource.body)
	require.False(t, ctx.upstreamViewPrepared)
	require.Nil(t, ctx.UpstreamRequest())
	require.Nil(t, ctx.Context())
}

func TestRequestContextWithParent(t *testing.T) {
	t.Parallel()

	// GIVEN
	ctx := newRequestContext()
	ctx.Init(
		context.TODO(),
		&envoy_auth.CheckRequest{
			Attributes: &envoy_auth.AttributeContext{
				Request: &envoy_auth.AttributeContext_Request{
					Http: &envoy_auth.AttributeContext_HttpRequest{},
				},
			},
		},
	)

	orig := ctx.Context()

	// WHEN
	actual := ctx.WithParent(t.Context())

	// THEN
	assert.Same(t, ctx, actual)
	assert.NotEqual(t, orig, ctx.Context())
	assert.Equal(t, t.Context(), ctx.Context())
}

func TestCanonicalizeHeaders(t *testing.T) {
	t.Parallel()

	// GIVEN
	headers := map[string]string{
		"x-foo":   "bar",
		"X-bAZ":   "foo",
		"cOntEnT": "value",
	}

	// WHEN
	actual := canonicalizeHeaders(headers)

	// THEN
	assert.Equal(t, http.Header{
		"X-Foo":   []string{"bar"},
		"X-Baz":   []string{"foo"},
		"Content": []string{"value"},
	}, actual)
}

func TestPeerAddress(t *testing.T) {
	t.Parallel()

	for uc, tc := range map[string]struct {
		ctx      func(t *testing.T) context.Context
		expected string
	}{
		"peer address is available": {
			ctx: func(t *testing.T) context.Context {
				t.Helper()

				return peer.NewContext(t.Context(), &peer.Peer{
					Addr: &net.TCPAddr{
						IP:   net.ParseIP("192.0.2.1"),
						Port: 12345,
					},
				})
			},
			expected: "192.0.2.1:12345",
		},
		"peer is not available": {
			ctx: func(t *testing.T) context.Context {
				t.Helper()

				return t.Context()
			},
		},
		"peer address is not available": {
			ctx: func(t *testing.T) context.Context {
				t.Helper()

				return peer.NewContext(t.Context(), &peer.Peer{})
			},
		},
	} {
		t.Run(uc, func(t *testing.T) {
			// WHEN
			actual := peerAddress(tc.ctx(t))

			// THEN
			assert.Equal(t, tc.expected, actual)
		})
	}
}
