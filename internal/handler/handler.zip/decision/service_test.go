// Copyright 2022 Dimitrij Drus <dadrus@gmx.de>
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//      http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// SPDX-License-Identifier: Apache-2.0

package decision

import (
	"fmt"
	"io"
	"net/http"
	"strings"
	"sync"
	"testing"
	"time"

	"github.com/inhies/go-bytesize"
	"github.com/rs/zerolog/log"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/mock"
	"github.com/stretchr/testify/require"

	"github.com/dadrus/heimdall/internal/cache/mocks"
	"github.com/dadrus/heimdall/internal/config"
	"github.com/dadrus/heimdall/internal/handler/listener"
	"github.com/dadrus/heimdall/internal/pipeline"
	mocks2 "github.com/dadrus/heimdall/internal/pipeline/mocks"
	"github.com/dadrus/heimdall/internal/x/testsupport"
)

func TestNewService(t *testing.T) {
	t.Parallel()

	// GIVEN
	conf := &config.Configuration{
		Serve: config.ServeConfig{
			Timeout: config.Timeout{
				Read:  11 * time.Second,
				Write: 12 * time.Second,
				Idle:  13 * time.Second,
			},
			Requests: config.IngressRequests{
				Headers: config.IngressRequestHeaders{
					MaxSize: 42 * bytesize.KB,
				},
			},
			HTTP2: config.IngressHTTP2{
				MaxConcurrentStreams: 17,
			},
		},
	}

	// WHEN
	srv := newService(
		conf,
		mocks.NewCacheMock(t),
		log.Logger,
		mocks2.NewExecutorMock(t),
	)

	// THEN
	assert.Equal(t, 11*time.Second, srv.ReadTimeout)
	assert.Equal(t, 12*time.Second, srv.WriteTimeout)
	assert.Equal(t, 13*time.Second, srv.IdleTimeout)
	assert.Equal(t, 42*bytesize.KB, bytesize.ByteSize(srv.MaxHeaderBytes))

	require.NotNil(t, srv.HTTP2)
	assert.Equal(t, 17, srv.HTTP2.MaxConcurrentStreams)

	assert.NotNil(t, srv.Handler)
	assert.NotNil(t, srv.ErrorLog)
}

//nolint:gocyclo
func TestHandleDecisionEndpointRequest(t *testing.T) {
	t.Parallel()

	for uc, tc := range map[string]struct {
		serviceConf    config.ServeConfig
		createRequest  func(t *testing.T, host string) *http.Request
		configureMocks func(t *testing.T, exec *mocks2.ExecutorMock)
		assertResponse func(t *testing.T, err error, response *http.Response)
	}{
		"no rules configured": {
			createRequest: func(t *testing.T, host string) *http.Request {
				t.Helper()

				req, err := http.NewRequestWithContext(
					t.Context(),
					http.MethodGet,
					fmt.Sprintf("http://%s/", host),
					nil,
				)
				require.NoError(t, err)

				return req
			},
			configureMocks: func(t *testing.T, exec *mocks2.ExecutorMock) {
				t.Helper()

				exec.EXPECT().Execute(mock.Anything).Return(pipeline.ErrNoRuleFound)
			},
			assertResponse: func(t *testing.T, err error, response *http.Response) {
				t.Helper()

				require.NoError(t, err)
				assert.Equal(t, http.StatusNotFound, response.StatusCode)

				data, err := io.ReadAll(response.Body)
				require.NoError(t, err)
				assert.Empty(t, data)
			},
		},
		"rule doesn't match method": {
			createRequest: func(t *testing.T, host string) *http.Request {
				t.Helper()

				req, err := http.NewRequestWithContext(
					t.Context(),
					http.MethodPost,
					fmt.Sprintf("http://%s/", host),
					nil,
				)
				require.NoError(t, err)

				return req
			},
			configureMocks: func(t *testing.T, exec *mocks2.ExecutorMock) {
				t.Helper()

				exec.EXPECT().Execute(mock.Anything).Return(pipeline.ErrNoRuleFound)
			},
			assertResponse: func(t *testing.T, err error, response *http.Response) {
				t.Helper()

				require.NoError(t, err)
				assert.Equal(t, http.StatusNotFound, response.StatusCode)

				data, err := io.ReadAll(response.Body)
				require.NoError(t, err)
				assert.Empty(t, data)
			},
		},
		"rule execution fails with authentication error": {
			createRequest: func(t *testing.T, host string) *http.Request {
				t.Helper()

				req, err := http.NewRequestWithContext(
					t.Context(),
					http.MethodPost,
					fmt.Sprintf("http://%s/", host),
					nil,
				)
				require.NoError(t, err)

				return req
			},
			configureMocks: func(t *testing.T, exec *mocks2.ExecutorMock) {
				t.Helper()

				exec.EXPECT().Execute(mock.Anything).Return(pipeline.ErrAuthentication)
			},
			assertResponse: func(t *testing.T, err error, response *http.Response) {
				t.Helper()

				require.NoError(t, err)
				assert.Equal(t, http.StatusUnauthorized, response.StatusCode)

				data, err := io.ReadAll(response.Body)
				require.NoError(t, err)
				assert.Empty(t, data)
			},
		},
		"rule execution fails with authorization error": {
			createRequest: func(t *testing.T, host string) *http.Request {
				t.Helper()

				req, err := http.NewRequestWithContext(
					t.Context(),
					http.MethodPost,
					fmt.Sprintf("http://%s/", host),
					nil,
				)
				require.NoError(t, err)

				return req
			},
			configureMocks: func(t *testing.T, exec *mocks2.ExecutorMock) {
				t.Helper()

				exec.EXPECT().Execute(mock.Anything).Return(pipeline.ErrAuthorization)
			},
			assertResponse: func(t *testing.T, err error, response *http.Response) {
				t.Helper()

				require.NoError(t, err)
				assert.Equal(t, http.StatusForbidden, response.StatusCode)

				data, err := io.ReadAll(response.Body)
				require.NoError(t, err)
				assert.Empty(t, data)
			},
		},
		"successful rule execution - request method, path and hostname " +
			"are taken from the real request (trusted proxy not configured)": {
			createRequest: func(t *testing.T, host string) *http.Request {
				t.Helper()

				req, err := http.NewRequestWithContext(
					t.Context(),
					http.MethodPost,
					fmt.Sprintf("http://%s/foobar", host),
					nil,
				)
				require.NoError(t, err)

				req.Header.Set("X-Forwarded-Proto", "https")
				req.Header.Set("X-Forwarded-Host", "test.com")
				req.Header.Set("X-Forwarded-Uri", "/bar")
				req.Header.Set("X-Forwarded-Method", http.MethodGet)

				return req
			},
			configureMocks: func(t *testing.T, exec *mocks2.ExecutorMock) {
				t.Helper()

				exec.EXPECT().Execute(
					mock.MatchedBy(func(ctx pipeline.ExecutionContext) bool {
						ctx.PrepareUpstreamView(nil)

						upstreamRequest := ctx.UpstreamRequest()
						upstreamRequest.AddHeader("X-Foo-Bar", "baz")
						upstreamRequest.SetCookie("X-Bar-Foo", "zab")

						pathMatched := ctx.Request().URL.Path == "/foobar"
						methodMatched := ctx.Request().Method == http.MethodPost

						return pathMatched && methodMatched
					}),
				).Return(nil)
			},
			assertResponse: func(t *testing.T, err error, response *http.Response) {
				t.Helper()

				require.NoError(t, err)
				assert.Equal(t, http.StatusOK, response.StatusCode)

				data, err := io.ReadAll(response.Body)
				require.NoError(t, err)
				assert.Empty(t, data)

				headerVal := response.Header.Get("X-Foo-Bar")
				assert.Equal(t, "baz", headerVal)

				cookies, err := http.ParseCookie(response.Header.Get("Cookie"))
				require.NoError(t, err)
				require.Len(t, cookies, 1)
				assert.Equal(t, "X-Bar-Foo", cookies[0].Name)
				assert.Equal(t, "zab", cookies[0].Value)
			},
		},
		"successful rule execution - request method, path and hostname " +
			"are not taken from the headers (trusted proxy not configured)": {
			createRequest: func(t *testing.T, host string) *http.Request {
				t.Helper()

				req, err := http.NewRequestWithContext(
					t.Context(),
					http.MethodPost,
					fmt.Sprintf("http://%s/foobar", host),
					nil,
				)
				require.NoError(t, err)

				req.Header.Set("X-Forwarded-Proto", "https")
				req.Header.Set("X-Forwarded-Host", "test.com")
				req.Header.Set("X-Forwarded-Uri", "/bar")
				req.Header.Set("X-Forwarded-Method", http.MethodGet)

				return req
			},
			configureMocks: func(t *testing.T, exec *mocks2.ExecutorMock) {
				t.Helper()

				exec.EXPECT().Execute(
					mock.MatchedBy(func(ctx pipeline.ExecutionContext) bool {
						ctx.PrepareUpstreamView(nil)

						upstreamRequest := ctx.UpstreamRequest()
						upstreamRequest.AddHeader("X-Foo-Bar", "baz")
						upstreamRequest.SetCookie("X-Bar-Foo", "zab")

						pathMatched := ctx.Request().URL.Path == "/foobar"
						methodMatched := ctx.Request().Method == http.MethodPost
						schemeMatched := ctx.Request().URL.Scheme == "http"
						hostMatched := ctx.Request().URL.Host != "test.com"

						return pathMatched && methodMatched && schemeMatched && hostMatched
					}),
				).Return(nil)
			},
			assertResponse: func(t *testing.T, err error, response *http.Response) {
				t.Helper()

				require.NoError(t, err)
				assert.Equal(t, http.StatusOK, response.StatusCode)

				data, err := io.ReadAll(response.Body)
				require.NoError(t, err)
				assert.Empty(t, data)

				headerVal := response.Header.Get("X-Foo-Bar")
				assert.Equal(t, "baz", headerVal)

				cookies, err := http.ParseCookie(response.Header.Get("Cookie"))
				require.NoError(t, err)
				require.Len(t, cookies, 1)
				assert.Equal(t, "X-Bar-Foo", cookies[0].Name)
				assert.Equal(t, "zab", cookies[0].Value)
			},
		},
		"successful rule execution - request method, path and hostname " +
			"all are not taken from the headers (trusted proxy configured and does not match host)": {
			serviceConf: config.ServeConfig{TrustedProxies: []string{"111.111.111.111"}},
			createRequest: func(t *testing.T, host string) *http.Request {
				t.Helper()

				req, err := http.NewRequestWithContext(
					t.Context(),
					http.MethodPost,
					fmt.Sprintf("http://%s/foobar", host),
					nil,
				)
				require.NoError(t, err)

				req.Header.Set("X-Forwarded-Proto", "https")
				req.Header.Set("X-Forwarded-Host", "test.com")
				req.Header.Set("X-Forwarded-Uri", "/bar")
				req.Header.Set("X-Forwarded-Method", http.MethodGet)

				return req
			},
			configureMocks: func(t *testing.T, exec *mocks2.ExecutorMock) {
				t.Helper()

				exec.EXPECT().Execute(
					mock.MatchedBy(func(ctx pipeline.ExecutionContext) bool {
						ctx.PrepareUpstreamView(nil)

						upstreamRequest := ctx.UpstreamRequest()
						upstreamRequest.AddHeader("X-Foo-Bar", "baz")
						upstreamRequest.SetCookie("X-Bar-Foo", "zab")

						pathMatched := ctx.Request().URL.Path == "/foobar"
						methodMatched := ctx.Request().Method == http.MethodPost
						schemeMatched := ctx.Request().URL.Scheme == "http"
						hostMatched := ctx.Request().URL.Host != "test.com"

						return pathMatched && methodMatched && schemeMatched && hostMatched
					}),
				).Return(nil)
			},
			assertResponse: func(t *testing.T, err error, response *http.Response) {
				t.Helper()

				require.NoError(t, err)
				assert.Equal(t, http.StatusOK, response.StatusCode)

				data, err := io.ReadAll(response.Body)
				require.NoError(t, err)
				assert.Empty(t, data)

				headerVal := response.Header.Get("X-Foo-Bar")
				assert.Equal(t, "baz", headerVal)

				cookies, err := http.ParseCookie(response.Header.Get("Cookie"))
				require.NoError(t, err)
				require.Len(t, cookies, 1)
				assert.Equal(t, "X-Bar-Foo", cookies[0].Name)
				assert.Equal(t, "zab", cookies[0].Value)
			},
		},
		"successful rule execution - only request method is sent via header" +
			"(trusted proxy configured and matches host)": {
			serviceConf: config.ServeConfig{TrustedProxies: []string{"0.0.0.0/0"}},
			createRequest: func(t *testing.T, host string) *http.Request {
				t.Helper()

				req, err := http.NewRequestWithContext(
					t.Context(),
					http.MethodPost,
					fmt.Sprintf("http://%s/foobar", host),
					nil,
				)
				require.NoError(t, err)

				req.Header.Set("X-Forwarded-Method", http.MethodGet)

				return req
			},
			configureMocks: func(t *testing.T, exec *mocks2.ExecutorMock) {
				t.Helper()

				exec.EXPECT().Execute(
					mock.MatchedBy(func(ctx pipeline.ExecutionContext) bool {
						req := ctx.Request()

						return req.URL.Scheme == "http" &&
							req.URL.Path == "/foobar" &&
							req.Method == http.MethodGet
					}),
				).Return(nil)
			},
			assertResponse: func(t *testing.T, err error, response *http.Response) {
				t.Helper()

				require.NoError(t, err)
				assert.Equal(t, http.StatusOK, response.StatusCode)
			},
		},
		"successful rule execution - only host is sent via header" +
			"(trusted proxy configured and matches host)": {
			serviceConf: config.ServeConfig{TrustedProxies: []string{"0.0.0.0/0"}},
			createRequest: func(t *testing.T, host string) *http.Request {
				t.Helper()

				req, err := http.NewRequestWithContext(
					t.Context(),
					http.MethodPost,
					fmt.Sprintf("http://%s/foobar", host),
					nil,
				)
				require.NoError(t, err)

				req.Header.Set("X-Forwarded-Host", "test.com")

				return req
			},
			configureMocks: func(t *testing.T, exec *mocks2.ExecutorMock) {
				t.Helper()

				exec.EXPECT().Execute(
					mock.MatchedBy(func(ctx pipeline.ExecutionContext) bool {
						req := ctx.Request()

						return req.URL.Scheme == "http" &&
							req.URL.Host == "test.com" &&
							req.URL.Path == "/foobar" &&
							req.Method == http.MethodPost
					}),
				).Return(nil)
			},
			assertResponse: func(t *testing.T, err error, response *http.Response) {
				t.Helper()

				require.NoError(t, err)
				assert.Equal(t, http.StatusOK, response.StatusCode)
			},
		},
		"successful rule execution - only path is sent via header" +
			"(trusted proxy configured and matches host)": {
			serviceConf: config.ServeConfig{TrustedProxies: []string{"0.0.0.0/0"}},
			createRequest: func(t *testing.T, host string) *http.Request {
				t.Helper()

				req, err := http.NewRequestWithContext(
					t.Context(),
					http.MethodPost,
					fmt.Sprintf("http://%s/foobar", host),
					nil,
				)
				require.NoError(t, err)

				req.Header.Set("X-Forwarded-Uri", "/bar")

				return req
			},
			configureMocks: func(t *testing.T, exec *mocks2.ExecutorMock) {
				t.Helper()

				exec.EXPECT().Execute(
					mock.MatchedBy(func(ctx pipeline.ExecutionContext) bool {
						req := ctx.Request()

						return req.URL.Scheme == "http" &&
							req.URL.Path == "/bar" &&
							req.Method == http.MethodPost
					}),
				).Return(nil)
			},
			assertResponse: func(t *testing.T, err error, response *http.Response) {
				t.Helper()

				require.NoError(t, err)
				assert.Equal(t, http.StatusOK, response.StatusCode)
			},
		},
		"successful rule execution - only scheme is sent via header" +
			"(trusted proxy configured and matches host)": {
			serviceConf: config.ServeConfig{TrustedProxies: []string{"0.0.0.0/0"}},
			createRequest: func(t *testing.T, host string) *http.Request {
				t.Helper()

				req, err := http.NewRequestWithContext(
					t.Context(),
					http.MethodPost,
					fmt.Sprintf("http://%s/foobar", host),
					nil,
				)
				require.NoError(t, err)

				req.Header.Set("X-Forwarded-Proto", "https")

				return req
			},
			configureMocks: func(t *testing.T, exec *mocks2.ExecutorMock) {
				t.Helper()

				exec.EXPECT().Execute(
					mock.MatchedBy(func(ctx pipeline.ExecutionContext) bool {
						req := ctx.Request()

						return req.URL.Scheme == "https" &&
							req.URL.Path == "/foobar" &&
							req.Method == http.MethodPost
					}),
				).Return(nil)
			},
			assertResponse: func(t *testing.T, err error, response *http.Response) {
				t.Helper()

				require.NoError(t, err)
				assert.Equal(t, http.StatusOK, response.StatusCode)
			},
		},
		"successful rule execution - scheme, host, path and method sent via header" +
			"(trusted proxy configured and matches host)": {
			serviceConf: config.ServeConfig{TrustedProxies: []string{"0.0.0.0/0"}},
			createRequest: func(t *testing.T, host string) *http.Request {
				t.Helper()

				req, err := http.NewRequestWithContext(
					t.Context(),
					http.MethodPost,
					fmt.Sprintf("http://%s/foobar", host),
					nil,
				)
				require.NoError(t, err)

				req.Header.Set("X-Forwarded-Proto", "https")
				req.Header.Set("X-Forwarded-Host", "test.com")
				req.Header.Set("X-Forwarded-Uri", "/bar")
				req.Header.Set("X-Forwarded-Method", http.MethodPatch)

				return req
			},
			configureMocks: func(t *testing.T, exec *mocks2.ExecutorMock) {
				t.Helper()

				exec.EXPECT().Execute(
					mock.MatchedBy(func(ctx pipeline.ExecutionContext) bool {
						req := ctx.Request()

						return req.URL.Scheme == "https" &&
							req.URL.Host == "test.com" &&
							req.URL.Path == "/bar" &&
							req.Method == http.MethodPatch
					}),
				).Return(nil)
			},
			assertResponse: func(t *testing.T, err error, response *http.Response) {
				t.Helper()

				require.NoError(t, err)
				assert.Equal(t, http.StatusOK, response.StatusCode)
			},
		},
		"request body exceeds limit with known content length": {
			serviceConf: config.ServeConfig{
				Requests: config.IngressRequests{
					Body: config.IngressRequestBody{
						MaxSize: 5 * bytesize.B,
					},
				},
			},
			createRequest: func(t *testing.T, host string) *http.Request {
				t.Helper()

				req, err := http.NewRequestWithContext(
					t.Context(),
					http.MethodPost,
					fmt.Sprintf("http://%s/", host),
					strings.NewReader("123456"),
				)
				require.NoError(t, err)

				return req
			},
			configureMocks: func(t *testing.T, _ *mocks2.ExecutorMock) {
				t.Helper()
			},
			assertResponse: func(t *testing.T, err error, response *http.Response) {
				t.Helper()

				require.NoError(t, err)
				require.NotNil(t, response)

				assert.Equal(t, http.StatusRequestEntityTooLarge, response.StatusCode)

				data, err := io.ReadAll(response.Body)
				require.NoError(t, err)
				assert.Empty(t, data)
			},
		},
		"request body exceeds limit while being read by pipeline": {
			serviceConf: config.ServeConfig{
				Requests: config.IngressRequests{
					Body: config.IngressRequestBody{
						MaxSize: 5 * bytesize.B,
					},
				},
			},
			createRequest: func(t *testing.T, host string) *http.Request {
				t.Helper()

				req, err := http.NewRequestWithContext(
					t.Context(),
					http.MethodPost,
					fmt.Sprintf("http://%s/", host),
					strings.NewReader("123456"),
				)
				require.NoError(t, err)

				req.ContentLength = -1

				return req
			},
			configureMocks: func(t *testing.T, exec *mocks2.ExecutorMock) {
				t.Helper()

				exec.EXPECT().
					Execute(mock.Anything).
					RunAndReturn(func(ctx pipeline.ExecutionContext) error {
						_, err := ctx.Request().Body()

						return err
					})
			},
			assertResponse: func(t *testing.T, err error, response *http.Response) {
				t.Helper()

				require.NoError(t, err)
				require.NotNil(t, response)

				assert.Equal(t, http.StatusRequestEntityTooLarge, response.StatusCode)

				data, err := io.ReadAll(response.Body)
				require.NoError(t, err)
				assert.Empty(t, data)
			},
		},
	} {
		t.Run(uc, func(t *testing.T) {
			// GIVEN
			port, err := testsupport.GetFreePort()
			require.NoError(t, err)

			srvConf := tc.serviceConf
			srvConf.Host = "127.0.0.1"
			srvConf.Port = port

			factory, err := listener.NewFactory(
				srvConf.Address(),
				srvConf.TLS,
				0,
				nil,
			)
			require.NoError(t, err)

			listener, err := factory.Create(t.Context())
			require.NoError(t, err)

			conf := &config.Configuration{Serve: srvConf}
			cch := mocks.NewCacheMock(t)
			exec := mocks2.NewExecutorMock(t)

			tc.configureMocks(t, exec)

			client := &http.Client{Transport: &http.Transport{}}

			decision := newService(conf, cch, log.Logger, exec)
			defer decision.Shutdown(t.Context())

			go func() {
				decision.Serve(listener)
			}()

			time.Sleep(50 * time.Millisecond)

			// WHEN
			resp, err := client.Do(tc.createRequest(t, srvConf.Address()))

			// THEN
			if err == nil {
				defer resp.Body.Close()
			}

			tc.assertResponse(t, err, resp)
		})
	}

	t.Run("rejects request if maximum number of requests is in flight", func(t *testing.T) {
		// GIVEN
		port, err := testsupport.GetFreePort()
		require.NoError(t, err)

		srvConf := config.ServeConfig{
			Host: "127.0.0.1",
			Port: port,
		}

		srvConf.Requests.MaxInFlight = 1
		srvConf.Respond.With.TooManyRequests.Code = http.StatusServiceUnavailable

		factory, err := listener.NewFactory(
			srvConf.Address(),
			srvConf.TLS,
			0,
			nil,
		)
		require.NoError(t, err)

		lstnr, err := factory.Create(t.Context())
		require.NoError(t, err)

		conf := &config.Configuration{Serve: srvConf}
		exec := mocks2.NewExecutorMock(t)

		requestEntered := make(chan struct{}, 2)
		releaseRequest := make(chan struct{})

		var releaseOnce sync.Once
		release := func() {
			releaseOnce.Do(func() {
				close(releaseRequest)
			})
		}
		t.Cleanup(release)

		exec.EXPECT().Execute(mock.Anything).
			Run(func(_ pipeline.ExecutionContext) {
				requestEntered <- struct{}{}

				<-releaseRequest
			}).
			Return(pipeline.ErrNoRuleFound)

		decision := newService(conf, mocks.NewCacheMock(t), log.Logger, exec)
		defer decision.Shutdown(t.Context())

		go func() {
			_ = decision.Serve(lstnr)
		}()

		time.Sleep(50 * time.Millisecond)

		client := &http.Client{Transport: &http.Transport{}}

		firstResponse := make(chan *http.Response, 1)
		firstError := make(chan error, 1)

		go func() {
			req, err := http.NewRequestWithContext(
				t.Context(),
				http.MethodGet,
				fmt.Sprintf("http://%s/", srvConf.Address()),
				nil,
			)
			if err != nil {
				firstError <- err

				return
			}

			resp, err := client.Do(req) //nolint:bodyclose
			firstResponse <- resp
			firstError <- err
		}()

		select {
		case <-requestEntered:
		case <-time.After(time.Second):
			release()
			require.FailNow(t, "first request did not enter pipeline")
		}

		secondRequest, err := http.NewRequestWithContext(
			t.Context(),
			http.MethodGet,
			fmt.Sprintf("http://%s/", srvConf.Address()),
			nil,
		)
		require.NoError(t, err)

		var (
			secondResponse *http.Response
			secondErr      error
		)

		secondDone := make(chan struct{})

		// WHEN
		go func() {
			defer close(secondDone)

			secondResponse, secondErr = client.Do(secondRequest) //nolint:bodyclose
		}()

		// THEN
		select {
		case <-requestEntered:
			release()

			require.FailNow(
				t,
				"second request entered pipeline while maximum number of requests was in flight",
			)

		case <-secondDone:
			require.NoError(t, secondErr)
			require.NotNil(t, secondResponse)
			defer secondResponse.Body.Close()

			assert.Equal(t, http.StatusServiceUnavailable, secondResponse.StatusCode)

			data, err := io.ReadAll(secondResponse.Body)
			require.NoError(t, err)
			assert.Empty(t, data)

		case <-time.After(time.Second):
			release()

			require.FailNow(t, "second request was not rejected immediately")
		}

		// WHEN
		release()

		// THEN
		select {
		case err := <-firstError:
			require.NoError(t, err)
		case <-time.After(time.Second):
			require.FailNow(t, "first request did not complete")
		}

		select {
		case resp := <-firstResponse:
			require.NotNil(t, resp)
			defer resp.Body.Close()

			assert.Equal(t, http.StatusNotFound, resp.StatusCode)
		case <-time.After(time.Second):
			require.FailNow(t, "first response was not received")
		}
	})
}
