// Copyright 2023 Dimitrij Drus <dadrus@gmx.de>
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//      http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// SPDX-License-Identifier: Apache-2.0

package requestcontext

import (
	"net/http"
	"net/url"
	"testing"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

func TestExtractURL(t *testing.T) {
	t.Parallel()

	for uc, tc := range map[string]struct {
		configureRequest func(t *testing.T, req *http.Request)
		assert           func(t *testing.T, extracted url.URL)
	}{
		"X-Forwarded-Proto set": {
			configureRequest: func(t *testing.T, req *http.Request) {
				t.Helper()

				req.Header.Set("X-Forwarded-Proto", "https")
				req.URL.RawQuery = url.Values{"foo": []string{"bar"}}.Encode()
			},
			assert: func(t *testing.T, extracted url.URL) {
				t.Helper()

				assert.Equal(t, "https", extracted.Scheme)
				assert.Equal(t, "heimdall.test.local", extracted.Host)
				assert.Equal(t, "/test%2Ffoo/bar/%5Bval%5D", extracted.EscapedPath())
				assert.Equal(t, url.Values{"foo": []string{"bar"}}, extracted.Query())
			},
		},
		"X-Forwarded-Host set": {
			configureRequest: func(t *testing.T, req *http.Request) {
				t.Helper()

				req.Header.Set("X-Forwarded-Host", "foobar")
				req.URL.RawQuery = url.Values{"foo": []string{"bar"}}.Encode()
			},
			assert: func(t *testing.T, extracted url.URL) {
				t.Helper()

				assert.Equal(t, "http", extracted.Scheme)
				assert.Equal(t, "foobar", extracted.Host)
				assert.Equal(t, "/test%2Ffoo/bar/%5Bval%5D", extracted.EscapedPath())
				assert.Equal(t, url.Values{"foo": []string{"bar"}}, extracted.Query())
			},
		},
		"X-Forwarded-Host is normalized to lowercase": {
			configureRequest: func(t *testing.T, req *http.Request) {
				t.Helper()

				req.Header.Set("X-Forwarded-Host", "FoObAr.Example.COM:8443")
			},
			assert: func(t *testing.T, extracted url.URL) {
				t.Helper()

				assert.Equal(t, "foobar.example.com:8443", extracted.Host)
			},
		},
		"request host fallback is normalized to lowercase": {
			configureRequest: func(t *testing.T, req *http.Request) {
				t.Helper()

				req.Host = "FooBar.Example.Local:9443"
			},
			assert: func(t *testing.T, extracted url.URL) {
				t.Helper()

				assert.Equal(t, "foobar.example.local:9443", extracted.Host)
			},
		},
		"X-Forwarded-Path is ignored": {
			configureRequest: func(t *testing.T, req *http.Request) {
				t.Helper()

				req.Header.Set("X-Forwarded-Path", "/bar%2Ftest/foo/%5Bval%5D")
				req.URL.RawQuery = url.Values{"foo": []string{"bar"}}.Encode()
			},
			assert: func(t *testing.T, extracted url.URL) {
				t.Helper()

				assert.Equal(t, "http", extracted.Scheme)
				assert.Equal(t, "heimdall.test.local", extracted.Host)
				assert.Equal(t, "/test%2Ffoo/bar/%5Bval%5D", extracted.EscapedPath())
				assert.Equal(t, url.Values{"foo": []string{"bar"}}, extracted.Query())
			},
		},
		"X-Forwarded-Uri set without dot segments": {
			configureRequest: func(t *testing.T, req *http.Request) {
				t.Helper()

				req.Header.Set("X-Forwarded-Uri", "/bar%2Ftest/foo/%5Bval%5D?bar=foo")
				req.URL.RawQuery = url.Values{"foo": []string{"bar"}}.Encode()
			},
			assert: func(t *testing.T, extracted url.URL) {
				t.Helper()

				assert.Equal(t, "http", extracted.Scheme)
				assert.Equal(t, "heimdall.test.local", extracted.Host)
				assert.Equal(t, "/bar%2Ftest/foo/%5Bval%5D", extracted.EscapedPath())
				assert.Equal(t, url.Values{"bar": []string{"foo"}}, extracted.Query())
			},
		},
		"X-Forwarded-Uri set with dot segments": {
			configureRequest: func(t *testing.T, req *http.Request) {
				t.Helper()

				req.Header.Set("X-Forwarded-Uri", "/bar/../test/foo/%5Bval%5D?bar=foo")
				req.URL.RawQuery = url.Values{"foo": []string{"bar"}}.Encode()
			},
			assert: func(t *testing.T, extracted url.URL) {
				t.Helper()

				assert.Equal(t, "http", extracted.Scheme)
				assert.Equal(t, "heimdall.test.local", extracted.Host)
				assert.Equal(t, "/test/foo/%5Bval%5D", extracted.EscapedPath())
				assert.Equal(t, url.Values{"bar": []string{"foo"}}, extracted.Query())
			},
		},
		"X-Forwarded-Uri set with encoded dot segments": {
			configureRequest: func(t *testing.T, req *http.Request) {
				t.Helper()

				req.Header.Set("X-Forwarded-Uri", "/bar/%2e.%2ftest/foo/%5Bval%5D?bar=foo")
				req.URL.RawQuery = url.Values{"foo": []string{"bar"}}.Encode()
			},
			assert: func(t *testing.T, extracted url.URL) {
				t.Helper()

				assert.Equal(t, "http", extracted.Scheme)
				assert.Equal(t, "heimdall.test.local", extracted.Host)
				assert.Equal(t, "/bar/%2e.%2ftest/foo/%5Bval%5D", extracted.EscapedPath())
				assert.Equal(t, url.Values{"bar": []string{"foo"}}, extracted.Query())
			},
		},
		"X-Forwarded-Uri retains encoded dot segments if another byte requires escaping": {
			configureRequest: func(t *testing.T, req *http.Request) {
				t.Helper()

				req.Header.Set("X-Forwarded-Uri", "/admin/%2e%2e%2fpublic/x|?bar=foo")
			},
			assert: func(t *testing.T, extracted url.URL) {
				t.Helper()

				assert.Equal(t, "/admin/../public/x|", extracted.Path)
				assert.Equal(t, "/admin/%2e%2e%2fpublic/x%7C", extracted.RawPath)
				assert.Equal(t, "/admin/%2e%2e%2fpublic/x%7C", extracted.EscapedPath())
				assert.Equal(t, url.Values{"bar": []string{"foo"}}, extracted.Query())
			},
		},
		"X-Forwarded-Uri retains encoded slash if another byte requires escaping": {
			configureRequest: func(t *testing.T, req *http.Request) {
				t.Helper()

				req.Header.Set("X-Forwarded-Uri", "/files/a%2Fb|")
			},
			assert: func(t *testing.T, extracted url.URL) {
				t.Helper()

				assert.Equal(t, "/files/a/b|", extracted.Path)
				assert.Equal(t, "/files/a%2Fb%7C", extracted.RawPath)
				assert.Equal(t, "/files/a%2Fb%7C", extracted.EscapedPath())
			},
		},
		"request URL retains encoded dot segments if another byte requires escaping": {
			configureRequest: func(t *testing.T, req *http.Request) {
				t.Helper()

				parsed, err := url.ParseRequestURI("/admin/%2e%2e%2fpublic/x|")
				require.NoError(t, err)

				req.URL = parsed
			},
			assert: func(t *testing.T, extracted url.URL) {
				t.Helper()

				assert.Equal(t, "/admin/../public/x|", extracted.Path)
				assert.Equal(t, "/admin/%2e%2e%2fpublic/x%7C", extracted.RawPath)
				assert.Equal(t, "/admin/%2e%2e%2fpublic/x%7C", extracted.EscapedPath())
			},
		},
		"request URL retains encoded slash if another byte requires escaping": {
			configureRequest: func(t *testing.T, req *http.Request) {
				t.Helper()

				parsed, err := url.ParseRequestURI("/files/a%2Fb|")
				require.NoError(t, err)

				req.URL = parsed
			},
			assert: func(t *testing.T, extracted url.URL) {
				t.Helper()

				assert.Equal(t, "/files/a/b|", extracted.Path)
				assert.Equal(t, "/files/a%2Fb%7C", extracted.RawPath)
				assert.Equal(t, "/files/a%2Fb%7C", extracted.EscapedPath())
			},
		},
		"Request path is used and ends with a slash": {
			configureRequest: func(t *testing.T, req *http.Request) {
				t.Helper()

				req.URL.Path = "/bar/baz/"
				req.URL.RawPath = "/bar/baz/"
			},
			assert: func(t *testing.T, extracted url.URL) {
				t.Helper()

				assert.Equal(t, "http", extracted.Scheme)
				assert.Equal(t, "heimdall.test.local", extracted.Host)
				assert.Equal(t, "/bar/baz/", extracted.EscapedPath())
				assert.Empty(t, extracted.Query())
			},
		},
		"Request path is used which is a slash": {
			configureRequest: func(t *testing.T, req *http.Request) {
				t.Helper()

				req.URL.Path = "/"
				req.URL.RawPath = "/"
			},
			assert: func(t *testing.T, extracted url.URL) {
				t.Helper()

				assert.Equal(t, "http", extracted.Scheme)
				assert.Equal(t, "heimdall.test.local", extracted.Host)
				assert.Equal(t, "/", extracted.EscapedPath())
				assert.Empty(t, extracted.Query())
			},
		},
		"Request URL with empty query": {
			configureRequest: func(t *testing.T, req *http.Request) {
				t.Helper()

				req.URL.ForceQuery = true
			},
			assert: func(t *testing.T, extracted url.URL) {
				t.Helper()

				assert.True(t, extracted.ForceQuery)
				assert.Equal(t, "http://heimdall.test.local/test%2Ffoo/bar/%5Bval%5D?", extracted.String())
			},
		},
	} {
		t.Run(uc, func(t *testing.T) {
			// GIVEN
			req, err := http.NewRequestWithContext(
				t.Context(),
				http.MethodGet,
				"http://heimdall.test.local/test%2Ffoo/bar/%5Bval%5D",
				nil,
			)
			require.NoError(t, err)

			tc.configureRequest(t, req)

			// WHEN
			extracted := extractURL(req)

			// THEN
			tc.assert(t, extracted)
		})
	}
}
